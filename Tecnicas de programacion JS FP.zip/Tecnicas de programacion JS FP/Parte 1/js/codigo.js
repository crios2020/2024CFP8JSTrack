// Implementación externa
alert('Hola JS!')