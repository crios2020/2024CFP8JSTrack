//Libreria pensada como decorado para curso de programación Inicial

/**
 * Función para generar voz
 * La voz es generada por el browser, se recomienda usar Chrome
 * Ej: hablar("Hola Mundo!!")
 * @param {*} mensaje Mensaje a generar
 */
function hablar(mensaje) {
    const message = new SpeechSynthesisUtterance(mensaje);
    speechSynthesis.speak(message);
}

/**
 * Función que devuelve la zona horaria
 * @returns Zona Horaria
 */
function zonaHoraria() {
    return Intl
        .DateTimeFormat()
        .resolvedOptions()
        .timeZone
        .replace("/", " ")
        .replace("_", " ");
}

/**
 * Verifica si funciona la conexión a internet
 * @returns true/false
 */
function internet() {
    const request = new XMLHttpRequest();
    request.open("GET", "https://api.ipify.org/?format=json", false); // `false` makes the request synchronous
    request.send();

    if (request.status === 200) {
        return true;
    }
    return false;
}

/**
 * Función que devuelve la dirección IP publica.
 * Utiliza el servicio publico https://api.ipify.org/?format=json
 */
function ip() {
    const request = new XMLHttpRequest();
    request.open("GET", "https://api.ipify.org/?format=json", false); // `false` makes the request synchronous
    request.send();

    if (request.status === 200) {
        const json = JSON.parse(request.responseText)
        return json.ip;
    }
    return "error";
}


