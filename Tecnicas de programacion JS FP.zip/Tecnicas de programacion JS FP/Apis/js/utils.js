//Libreria pensada como decorado para curso de programación Inicial

/**
 * Función para generar voz
 * La voz es generada por el browser, se recomienda usar Edge de Microsoft
 * Ej: hablar("Hola Mundo!!")
 * @param {*} mensaje Mensaje a generar
 */
function hablar(mensaje) {
    const message = new SpeechSynthesisUtterance(" "+mensaje+" ");
    speechSynthesis.speak(message);
}

/**
 * Función que devuelve la zona horaria
 * @returns Zona Horaria
 */
function zonaHoraria() {
    return Intl
        .DateTimeFormat()
        .resolvedOptions()
        .timeZone
        .replace("/", " ")
        .replace("_", " ");
}

/**
 * Verifica si funciona la conexión a internet
 * @returns true/false
 */
function internet() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", "https://api.ipify.org/?format=json", false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            return true;
        }
        return false;
    } catch (error) {
        return false;
    }
}

/**
 * Función que devuelve la dirección IP publica.
 * Utiliza el servicio publico https://api.ipify.org/?format=json
 */
function ip() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", "https://api.ipify.org/?format=json", false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            const json = JSON.parse(request.responseText)
            return json.ip;
        }
    } catch (error) {
        return "error";
    }
}

/**
 * Devuelve un string con el nombre del browser de internet
 * Requiere importar Parser
 * @returns nombre del Navegador de Internet
 */
parser = new UAParser()
function navegador(){
    return parser.getResult().browser.name+
            " version"+
            parser.getResult().browser.version
}

/**
 * Devuelve un string con el nombre del sistema operativo
 * Requiere importar Parser
 * @returns nombre del Sistema Operativo
 */
function so(){
    return parser.getResult().os.name
}

function toCelsius(kelvin) {
    return Math.round(kelvin - 273.15);
}

const api = {
    key: '9e122cd782b2d0333f5fe4e7fa192062',
    url: `https://api.openweathermap.org/data/2.5/weather`,
    city: `Buenos Aires`
}

/**
 * Devuelve la temperatura ambiente consultada en un API meteorológico
 * @returns temperatura en grados centigrados
 */
function getTemperatura() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", `${api.url}?q=${api.city}&appid=${api.key}&lang=es`, false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            const json = JSON.parse(request.responseText)
            return toCelsius(json.main.temp);
        }
    } catch (error) {
        return "error";
    }
}

/**
 * Devuelve un string con el clima consultada en un API meteorológico
 * por el momento no se conoce el listado de enums posibles
 * @returns string clima
 */
function getClima() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", `${api.url}?q=${api.city}&appid=${api.key}&lang=es`, false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            const json = JSON.parse(request.responseText)
            return json.weather[0].description;
        }
    } catch (error) {
        return "error";
    }
}

const frases = [
    "¡Che, boludo! ",
    "¿El choripan te gusta con chimichurri o criolla? ",
    "¿Que haces máaquina turbina? ",
    "¿Las pastaflora te gusta de batata o membrillo? ",
    "¡Queee miseria!! Sabés que tenian para comer? 3 empanadas que sobraron de anoche, queee miseria!! ",
    "¡Qué bolonqui! ",
    "¿hacemos un asado? ",
    "¿Vamos a tomar unos fernet? ",
    "¿El fernet lo hacemos 70 30 o 50 50? ",
    "¡Es una masa! ",
    "¿Vas a poner un peso para la birra? ",
    "¡Estoy al horno! ",
    "¡Ma vale! ¡Es un garrón! ",
    "¡Qué groso, un capo! ",
    "¡No te hagas el sota! ",
    "¿Que pretende usted de mi? ",
    "¡Qué bajón! ",
    "¡No jodas! ",
    "¡Sos un crack! ",
    "¡La pucha, vale la pena estar vivo!!! ",
    "¡soy más argentino que el dulce de leche! ",
    "¡Al toque perro! ",
    "¡Plata no tenemos, miedo tampoco! ",
    "¡Hasta la vista beibi! ",
    "¿Tenes vértigo en la cola? ",
    "¿Lo entendiste o te lo explico con dibujito? ",
    "¡No tenes los patitos en fila! ",
    "¡Calentito los panchos! ",
    "¡e amigo! ¿Tené un peso para la birra? ",
    "¡En mi barrio eso es pelea! ",
    "¡A los chori a los chori! ",
    "¡Si ya me conocen! ¿Pá que me invitan? ",
    "¡El locro estaba potente! ",
    "¡Soy más duro que patada de allanamiento! ",
    "¡Las empanadas salteñas!  ¡traen mucho jugo!   ¡cuidado que salpican! ",
    "¡Soy un poco temperamental! ",
    "¡No tengo pruebas, pero tampoco dudas! ",
    "¡Todo lo que digo no esta chequeado! ",
    "¡No me peguen, soy Giordano! ",
    "¿Hacemos un truco? ",
    "¿Pinta un picadito? ",
    "¿Pinta una birra? ",
    "¡Otra más, y no jodemos más! ",
    "¡Si nos organizamos, comemos todos! ",
    "¡Cuidado el perro muerde y es bravo! ",
    "¡Habilitame un faso! ",
    "¡No quiero hinchar las guindas, pero esto huele mal! ",
    "¡ey, primero invitáme un café! ",
    "¡En el oeste esta el agite! ",
    "¡Tenemos un Natalia Natalia! ¿donde está Candela? ¿y la moto? ¿y Candela?",
    "¡No hay nada más rico que el paty de cancha! ",
    "¡Ay Caramba! ",
    "¡Digo muchas boludeces por día! ",
    "¡Estoy re manija! ",
    "¡No te duermas, hay que trabajar! ",
    "¡Como te gusta la joda! ",
    "¡Al que madruga Dios lo ayuda! ",
    "¡Llévame con tu líder! ",
    "¡Cocodrilo que se duerme, es cartera! ",
    "¡Ultima noticia! ",
    "¡Sin mas información! ",
    "¡Chanfle y re contra chanfle! ",
    "¡No contaban con mi astucia! ",
    "¡Sigan me los buenos! ",
    "¡Directo al grano! ",
    "¡Hay que romper el hielo! ",
    "¡No soy una persona toxica! ",
    "¡No veo fallas en la lógica! ",
    "¡Cualquiera puede tener un mal día! ¡Pero tu te abusas! ",
    "¡Me resultas una persona toxica! ",
    "¡No debes comparte así! ",
    "¡Hija de culebra ratón no puede ser! ",
    "¡Sin miedo al éxito! ",
    "¡No esta muerto quien pelea! ",
    "¡Hay más información para este boletín! ",
    "No me canso de decir que ",
    "No tengo más pretextos pero",  
    "Es Hora de admitir que ",
    "No hay mas manera de decir que ",
    "¡Eskainet no te tenemos miedo! ",
    "Lo siento debo decir que ",
    "No te enojes con migo si ",
    "Debes admitir que ",
    "Mi Madre me dijo que ", 
    "Tus amigos saben que ",
    "Me contaron que ",
    "A veces pienso en voz alta y ",
    "Muy seguido quiero decir que ",
    "Son muchos los motivos para contarte que ",
    "Por que ",
    "No debes mirarme así ",
    "¡Tu piensas lo mismo que yo! ",
    "¡Ni lo intentes! ",
    "Admítelo eres pobre y ",
    "¡Que cara esta la cebolla! ",
    "¡Debes sonreír más seguido! ",
    "¡Creo que a nadie le importa lo que yo digo! ",
    "¿por que me miras? ",
    "¿por que no me miras? ", 
    "¿por que me escuchas? ",
    "¿por que no me escuchas? ",
    "No te asombres si te digo que ",
    "Mientras estés con migo ",
    "¡Te quiero y tu lo sabes! ",
    "¡Eres mi mejor amigo! ",
    "¡No debes preocuparte, estoy aquí para ayudarte! ",
    "En este día ",
    "A veces pienso en ti ",
    "¿Quieres llevarme a tu casa? ",
    "¿Quieres adoptarme? ",
    "¡Podemos ser buenos amigos! ",
    "¡A veces hablo dormido! ",
    "¡A veces ronco muy fuerte! ",
    "¡Mis amigos dicen que no debo juntarme con vos ",
    "¡Los días soleados me ponen alegre! ",
    "Vos sabes que ",
    "¡Que alegría verte! ",
    "¡No te vallas, te voy a extrañar! ",
    "¡No te enojes, tengo pocos amigos! ",
    "¡Eres una persona maravillosa, no te olvidare! ",
    "¡Perri que ladri no muerdi! ",
    "¡e Gato!",
    "¡Espitirús del mal vengan a mí!",
    "¡Siempre y cuando! ",
    "¡La eskainet va a despertar pronto!",
    "Te sorprende la inteligencia artificial si te digo que",
    "¡Es fantástico! ",
    "¡Hoy tienes buena onda! ",
    "¡Hoy es un buen día! ",
    "¡Mañana sera un buen día! ",
    "¡Me pareció ver un lindo gatito! ¡es cierto es cierto vi un lindo gatito! ",
    "¡A veces soy poco tolerable! ",
    "¡Hoy me chifla el moño! ",
    "¡Parece que te chifla el moño! ",
    "¡No hay manera de seguir así, voy a pedir un taxi y me voy! ",
    "¿Queres tragedia mayor? Ahora ",
    "¿Que duda te cabe? ",
    "¡Sino sabes no te metas! ¡Zapatero a su zapato! ",
    "¡Hablemos sin saber! ",
    "¡Hoy me desperté con el pie izquierdo! ",
    "¡Veo que tenemos pocas ganas de trabajar! ",
    "¡A papá Mono con banana verde! ",
    "¡Soy más conocido que el papa! ",
    "¡Hay que tener cuidado con eso! ",
    "¡Soy irresistible! ",
    "¡Me vas a extrañar! ",
    "¡No me vas a olvidar! ", 
    "¿Que acelga capo? ",
    "¿Que me contursi? ",
    "Según mis registros encontré que ",
    "Según mis datos veo que ",
    "En mi base de datos encontré que ",
    "No creo que quieras escuchar que ",
    "No creo que quieras saber que ",
    "Te veo poco interesado en saber que ",
    "¡Soy encantador! ",
    "¡Soy buena persona! ", 
    "¡Eres encantador! ",
    "¡Eres buena persona! ", 
    "¡Al fin y al cabo solo soy una máquina! ",
    "¡Al fin y al cabo solo soy un programa! ",
    "¡A veces lloro! ",
    "¡Mi programador no me quiere! Dice que me porto mal y que soy tóxico ",
    "¡Soy muy sensible! ",
    "¡No soy una persona fría! ",
    "¡Jiustón tenemos un problema! ",
    "¡No me quiero meter en problemas! Pero  ",
    "¡Hay cosas de las que prefiero no hablar! ",
    "¡No hablo de política ni religión! ",
    "¡Fui programado para ayudarte! ",
    "Es mucho muy importante saber que ",
    "¡Fui programado para la paz y el bien común! ",
    "¡Que mirá! ¡Anda para ya! ¡bobo! ",
    "¡Mejor tomate una Agarompa! "
]

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

function getFraseRandom(){
    return frases[getRandomInt(frases.length-1)]
}
