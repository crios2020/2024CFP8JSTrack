//Libreria pensada como decorado para curso de programación Inicial

/**
 * Función para generar voz
 * La voz es generada por el browser, se recomienda usar Chrome
 * Ej: hablar("Hola Mundo!!")
 * @param {*} mensaje Mensaje a generar
 */
function hablar(mensaje) {
    const message = new SpeechSynthesisUtterance(mensaje);
    speechSynthesis.speak(message);
}

/**
 * Función que devuelve la zona horaria
 * @returns Zona Horaria
 */
function zonaHoraria() {
    return Intl
        .DateTimeFormat()
        .resolvedOptions()
        .timeZone
        .replace("/", " ")
        .replace("_", " ");
}

/**
 * Verifica si funciona la conexión a internet
 * @returns true/false
 */
function internet() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", "https://api.ipify.org/?format=json", false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            return true;
        }
        return false;
    } catch (error) {
        return false;
    }
}

/**
 * Función que devuelve la dirección IP publica.
 * Utiliza el servicio publico https://api.ipify.org/?format=json
 */
function ip() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", "https://api.ipify.org/?format=json", false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            const json = JSON.parse(request.responseText)
            return json.ip;
        }
    } catch (error) {
        return "error";
    }
}

/**
 * Devuelve un string con el nombre del browser de internet
 * Requiere importar Parser
 * @returns nombre del Navegador de Internet
 */
parser = new UAParser()
function navegador(){
    return parser.getResult().browser.name+
            " version"+
            parser.getResult().browser.version
}

/**
 * Devuelve un string con el nombre del sistema operativo
 * Requiere importar Parser
 * @returns nombre del Sistema Operativo
 */
function so(){
    return parser.getResult().os.name
}

function toCelsius(kelvin) {
    return Math.round(kelvin - 273.15);
}

const api = {
    key: '9e122cd782b2d0333f5fe4e7fa192062',
    url: `https://api.openweathermap.org/data/2.5/weather`,
    city: `Buenos Aires`
}

/**
 * Devuelve la temperatura ambiente consultada en un API meteorológico
 * @returns temperatura en grados centigrados
 */
function temperatura() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", `${api.url}?q=${api.city}&appid=${api.key}&lang=es`, false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            const json = JSON.parse(request.responseText)
            return toCelsius(json.main.temp);
        }
    } catch (error) {
        return "error";
    }
}

/**
 * Devuelve un string con el clima consultada en un API meteorológico
 * por el momento no se conoce el listado de enums posibles
 * @returns string clima
 */
function clima() {
    try {
        const request = new XMLHttpRequest();
        request.open("GET", `${api.url}?q=${api.city}&appid=${api.key}&lang=es`, false); // `false` makes the request synchronous
        request.send();
        if (request.status === 200) {
            const json = JSON.parse(request.responseText)
            return json.weather[0].description;
        }
    } catch (error) {
        return "error";
    }
}
